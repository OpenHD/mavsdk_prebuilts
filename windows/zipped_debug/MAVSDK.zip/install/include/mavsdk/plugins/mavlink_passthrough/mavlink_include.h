#pragma once

#include "mavlink/v2.0/openhd/mavlink.h"
